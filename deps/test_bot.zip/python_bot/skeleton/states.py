'''
Encapsulates game and round state information for the player.
'''
from collections import namedtuple
from .actions import FoldAction, CallAction, CheckAction, RaiseAction

# bankroll is your own; team_bankroll adds your teammate's
GameState = namedtuple('GameState', ['bankroll', 'team_bankroll', 'game_clock', 'round_num'])
TerminalState = namedtuple('TerminalState', ['deltas', 'previous_state'])

NUM_ROUNDS = 1000
STARTING_STACK = 200
BIG_BLIND = 2
SMALL_BLIND = 1
# Two replicas of each team's bot sit in alternating seats, so your teammate is
# always 2 seats away from you: seat (active + 2) % NUM_PLAYERS.
NUM_PLAYERS = 4


class RoundState(namedtuple('_RoundState', ['active', 'street', 'pips', 'stacks', 'contributions', 'acted',
                                            'folded', 'min_raise', 'hands', 'board', 'previous_state'])):
    '''
    Encodes the game tree for one round of poker.

    Seats are numbered from the small blind: 0 small blind, 1 big blind, 2 first
    to act preflop, 3 dealer. active is the seat to act. pips are this street's
    bets and contributions the whole round's. acted[seat] is the top bet on this
    street right after the seat last acted on it (-1 if it has not acted yet).
    min_raise is the smallest legal raise amount: the last full bet or raise on
    this street, at least the big blind. Hands you have not seen are empty lists.

    Betting is standard no-limit: anyone may bet or raise up to their whole
    stack, even more than anyone else can call (the part no one matched comes
    back at showdown, through the side pots). An all-in raise smaller than a
    full raise does not reopen the betting to a seat that has already acted.
    '''

    def live(self):
        '''
        The seats that have not folded.
        '''
        return [seat for seat in range(NUM_PLAYERS) if not self.folded[seat]]

    def bettors(self):
        '''
        The seats that can still bet: not folded and not all in.
        '''
        return [seat for seat in self.live() if self.stacks[seat] > 0]

    def pending(self):
        '''
        The seats that still have to act on this street: those that can bet and
        have not acted since the last bet or raise. A lone seat with chips that
        owes nothing has no one to bet against, so it does not act.
        '''
        top = max(self.pips)
        bettors = self.bettors()
        if len(bettors) == 1 and self.pips[bettors[0]] == top:
            return []
        return [seat for seat in bettors if self.acted[seat] < top]

    def raise_bounds(self):
        '''
        Returns a tuple of the minimum and maximum legal raises (the raiser's new pip).
        A raise smaller than the minimum is legal only all in.
        '''
        max_raise = self.pips[self.active] + self.stacks[self.active]
        return (min(max(self.pips) + self.min_raise, max_raise), max_raise)

    def legal_actions(self):
        '''
        Returns a set which corresponds to the active player's legal moves.
        '''
        active = self.active
        top = max(self.pips)
        continue_cost = top - self.pips[active]
        actions = {FoldAction, CheckAction} if continue_cost == 0 else {FoldAction, CallAction}
        reopened = self.acted[active] < 0 or top - self.acted[active] >= self.min_raise
        if self.stacks[active] > continue_cost and len(self.bettors()) > 1 and reopened:
            actions.add(RaiseAction)
        return actions

    def proceed_street(self):
        '''
        Resets the players' pips and advances the game tree to the next street,
        or to showdown after the river. A street on which fewer than two players
        can bet has no betting: no one is pending.
        '''
        if self.street == 5:
            return TerminalState([0] * NUM_PLAYERS, self)
        state = RoundState(0, 3 if self.street == 0 else self.street + 1, [0] * NUM_PLAYERS, self.stacks,
                           self.contributions, (-1,) * NUM_PLAYERS, self.folded, BIG_BLIND, self.hands,
                           self.board, self)
        pending = state.pending()
        return state._replace(active=pending[0]) if pending else state

    def proceed(self, action):
        '''
        Advances the game tree by one action performed by the active player.
        '''
        active = self.active
        top = max(self.pips)
        folded = self.folded
        min_raise = self.min_raise
        amount = 0
        if isinstance(action, FoldAction):
            folded = folded[:active] + (True,) + folded[active + 1:]
        elif isinstance(action, CallAction):
            amount = min(top - self.pips[active], self.stacks[active])  # all in for less if short
        elif isinstance(action, RaiseAction):
            amount = action.amount - self.pips[active]
            min_raise = max(min_raise, action.amount - top)  # only a full raise sets a new minimum
        pips = list(self.pips)
        stacks = list(self.stacks)
        contributions = list(self.contributions)
        pips[active] += amount
        stacks[active] -= amount
        contributions[active] += amount
        acted = self.acted[:active] + (max(pips),) + self.acted[active + 1:]
        state = RoundState(active, self.street, pips, stacks, contributions, acted, folded, min_raise,
                           self.hands, self.board, self)
        if folded.count(False) == 1:  # everyone else folded
            return TerminalState([0] * NUM_PLAYERS, state)
        pending = state.pending()
        if not pending:
            return state.proceed_street()
        return state._replace(active=min(pending, key=lambda seat: (seat - active) % NUM_PLAYERS))
