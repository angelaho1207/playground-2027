'''
The infrastructure for interacting with the engine.
'''
import argparse
import socket
from .actions import FoldAction, CallAction, CheckAction, RaiseAction
from .states import GameState, TerminalState, RoundState
from .states import NUM_PLAYERS, STARTING_STACK, BIG_BLIND, SMALL_BLIND
from .bot import Bot


class Runner():
    '''
    Interacts with the engine.
    '''

    def __init__(self, pokerbot, socketfile):
        self.pokerbot = pokerbot
        self.socketfile = socketfile

    def receive(self):
        '''
        Generator for incoming messages from the engine.
        '''
        while True:
            line = self.socketfile.readline()
            if not line:  # the engine closed the connection
                break
            yield line.strip().split(' ')

    def send(self, action):
        '''
        Encodes an action and sends it to the engine.
        '''
        if isinstance(action, FoldAction):
            code = 'F'
        elif isinstance(action, CallAction):
            code = 'C'
        elif isinstance(action, CheckAction):
            code = 'K'
        else:  # isinstance(action, RaiseAction)
            code = 'R' + str(action.amount)
        self.socketfile.write(code + '\n')
        self.socketfile.flush()

    def run(self):
        '''
        Reconstructs the game tree based on the action history received from the engine.
        '''
        game_state = GameState(0, 0, 0., 1)
        round_state = None
        active = 0
        round_flag = True
        for packet in self.receive():
            for clause in packet:
                if clause[0] == 'T':
                    game_state = game_state._replace(game_clock=float(clause[1:]))
                elif clause[0] == 'P':
                    active = int(clause[1:])
                elif clause[0] == 'H':
                    hands = [[] for _ in range(NUM_PLAYERS)]
                    hands[active] = clause[1:].split(',')
                    pips = [SMALL_BLIND, BIG_BLIND] + [0] * (NUM_PLAYERS - 2)
                    stacks = [STARTING_STACK - pip for pip in pips]
                    round_state = RoundState(2 % NUM_PLAYERS, 0, pips, stacks, list(pips), (-1,) * NUM_PLAYERS,
                                             (False,) * NUM_PLAYERS, BIG_BLIND, hands, [], None)
                    if round_flag:
                        self.pokerbot.handle_new_round(game_state, round_state, active)
                        round_flag = False
                elif clause[0] == 'F':
                    round_state = round_state.proceed(FoldAction())
                elif clause[0] == 'C':
                    round_state = round_state.proceed(CallAction())
                elif clause[0] == 'K':
                    round_state = round_state.proceed(CheckAction())
                elif clause[0] == 'R':
                    round_state = round_state.proceed(RaiseAction(int(clause[1:])))
                elif clause[0] == 'B':
                    board = clause[1:].split(',')
                    while round_state.street < len(board):  # streets on which no one could bet
                        round_state = round_state.proceed_street()
                    round_state = round_state._replace(board=board)
                elif clause[0] == 'O':
                    seat, cards = clause[1:].split(':')
                    previous_state = round_state.previous_state if isinstance(round_state, TerminalState) else round_state
                    previous_state.hands[int(seat)] = cards.split(',')  # every state of the round shares hands
                elif clause[0] == 'A':
                    deltas = [int(delta) for delta in clause[1:].split(',')]
                    previous_state = round_state.previous_state if isinstance(round_state, TerminalState) else round_state
                    round_state = TerminalState(deltas, previous_state)
                    self.pokerbot.handle_round_over(game_state, round_state, active)
                    game_state = GameState(game_state.bankroll + deltas[active],
                                           game_state.team_bankroll + deltas[active] + deltas[(active + 2) % NUM_PLAYERS],
                                           game_state.game_clock, game_state.round_num + 1)
                    round_flag = True
                elif clause[0] == 'Q':
                    return
            if round_flag or isinstance(round_state, TerminalState):  # ack the engine
                self.send(CheckAction())
            else:
                assert active == round_state.active
                action = self.pokerbot.get_action(game_state, round_state, active)
                self.send(action)


def parse_args():
    '''
    Parses arguments corresponding to socket connection information.
    '''
    parser = argparse.ArgumentParser(prog='python3 player.py')
    parser.add_argument('--host', type=str, default='localhost', help='Host to connect to, defaults to localhost')
    parser.add_argument('port', type=int, help='Port on host to connect to')
    return parser.parse_args()

def run_bot(pokerbot, args):
    '''
    Runs the pokerbot.
    '''
    assert isinstance(pokerbot, Bot)
    try:
        sock = socket.create_connection((args.host, args.port))
    except OSError:
        print('Could not connect to {}:{}'.format(args.host, args.port))
        return
    socketfile = sock.makefile('rw')
    runner = Runner(pokerbot, socketfile)
    runner.run()
    socketfile.close()
    sock.close()
