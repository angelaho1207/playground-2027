'''
This file contains the base class that you should implement for your pokerbot.
'''


class Bot():
    '''
    The base class for a pokerbot.
    '''

    def handle_new_round(self, game_state, round_state, active):
        '''
        Called when a new round starts. Called NUM_ROUNDS times.

        Arguments:
        game_state: the GameState object.
        round_state: the RoundState object.
        active: your seat this round (0 small blind, 1 big blind, 2 first to act preflop, 3 dealer).

        Returns:
        Nothing.
        '''
        raise NotImplementedError('handle_new_round')

    def handle_round_over(self, game_state, terminal_state, active):
        '''
        Called when a round ends. Called NUM_ROUNDS times.

        Arguments:
        game_state: the GameState object.
        terminal_state: the TerminalState object.
        active: your seat this round (0 small blind, 1 big blind, 2 first to act preflop, 3 dealer).

        Returns:
        Nothing.
        '''
        raise NotImplementedError('handle_round_over')

    def get_action(self, game_state, round_state, active):
        '''
        Where the magic happens - your code should implement this function.
        Called any time the engine needs an action from your bot.

        Arguments:
        game_state: the GameState object.
        round_state: the RoundState object.
        active: your seat this round (0 small blind, 1 big blind, 2 first to act preflop, 3 dealer).

        Returns:
        Your action.
        '''
        raise NotImplementedError('get_action')

    def choose_card(self, game_state, round_state, active):
        '''
        Called at a Week 2+ showdown: your team plays one hand made of the board
        and the cards you and your live teammates submit, privately.

        Arguments:
        game_state: the GameState object.
        round_state: the RoundState object after the river's betting.
        active: your seat this round.

        Returns:
        The index (0 or 1) of the card in your hand to submit, or None for no card.
        '''
        raise NotImplementedError('choose_card')
