'''
Simple example pokerbot, written in Python.
'''
from skeleton.actions import FoldAction, CallAction, CheckAction, RaiseAction
from skeleton.states import GameState, TerminalState, RoundState
from skeleton.states import NUM_ROUNDS, NUM_PLAYERS, STARTING_STACK, BIG_BLIND, SMALL_BLIND
from skeleton.bot import Bot
from skeleton.runner import parse_args, run_bot

import random


class Player(Bot):
    '''
    A pokerbot.
    '''

    def __init__(self):
        '''
        Called when a new game starts. Called exactly once.

        Arguments:
        Nothing.

        Returns:
        Nothing.
        '''
        pass

    def handle_new_round(self, game_state, round_state, active):
        '''
        Called when a new round starts. Called NUM_ROUNDS times.

        Arguments:
        game_state: the GameState object.
        round_state: the RoundState object.
        active: your seat this round.

        Returns:
        Nothing.
        '''
        my_bankroll = game_state.bankroll  # the total number of chips you've gained or lost from the beginning of the game to the start of this round
        team_bankroll = game_state.team_bankroll  # the same for you and your teammate together: your team's score
        game_clock = game_state.game_clock  # the total number of seconds your bot has left to play this game
        round_num = game_state.round_num  # the round number from 1 to NUM_ROUNDS
        my_cards = round_state.hands[active]  # your cards
        teammates = round_state.teammates  # your teammates' seats
        dealer = active == NUM_PLAYERS - 1  # True if you are the dealer
        pass

    def handle_round_over(self, game_state, terminal_state, active):
        '''
        Called when a round ends. Called NUM_ROUNDS times.

        Arguments:
        game_state: the GameState object.
        terminal_state: the TerminalState object.
        active: your seat this round.

        Returns:
        Nothing.
        '''
        my_delta = terminal_state.deltas[active]  # your bankroll change from this round
        team_delta = my_delta + sum(terminal_state.deltas[seat] for seat in terminal_state.previous_state.teammates)  # your team's
        previous_state = terminal_state.previous_state  # RoundState before payoffs
        street = previous_state.street  # 0, 3, 4, or 5 representing when this round ended
        my_cards = previous_state.hands[active]  # your cards
        shown = {seat: cards for seat, cards in enumerate(previous_state.hands) if cards}  # cards revealed at showdown
        pass

    def get_action(self, game_state, round_state, active):
        '''
        Where the magic happens - your code should implement this function.
        Called any time the engine needs an action from your bot.

        Arguments:
        game_state: the GameState object.
        round_state: the RoundState object.
        active: your seat this round.

        Returns:
        Your action.
        '''
        legal_actions = round_state.legal_actions()  # the actions you are allowed to take
        street = round_state.street  # 0, 3, 4, or 5 representing pre-flop, flop, turn, or river respectively
        my_cards = round_state.hands[active]  # your cards
        board_cards = round_state.board  # the board cards
        my_pip = round_state.pips[active]  # the number of chips you have contributed to the pot this round of betting
        my_stack = round_state.stacks[active]  # the number of chips you have remaining
        continue_cost = max(round_state.pips) - my_pip  # the number of chips needed to stay in the pot
        teammates = round_state.teammates  # your teammates' seats
        teammate_in = any(not round_state.folded[seat] for seat in teammates)  # whether a teammate is still in the hand
        pot = sum(round_state.contributions)  # every chip put in this round
        if RaiseAction in legal_actions and random.random() < 0.25:
            min_raise, max_raise = round_state.raise_bounds()  # the smallest and largest legal raises
            return RaiseAction(min_raise)
        if CheckAction in legal_actions:  # check-call
            return CheckAction()
        if random.random() < 0.25:
            return FoldAction()
        return CallAction()

    def choose_card(self, game_state, round_state, active):
        '''
        Called at a Week 2+ showdown to pick the hole card to add to your team's hand.

        Arguments:
        game_state: the GameState object.
        round_state: the RoundState object.
        active: your seat this round.

        Returns:
        The index (0 or 1) of the card in your hand to submit, or None for no card.
        '''
        my_cards = round_state.hands[active]  # your cards
        teammates = round_state.teammates  # your teammates' seats
        ranks = '23456789TJQKA'
        return max(range(len(my_cards)), key=lambda i: ranks.index(my_cards[i][0]))  # the higher card


if __name__ == '__main__':
    run_bot(Player(), parse_args())
